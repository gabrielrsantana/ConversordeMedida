
export class Unidade{
    constructor(
        public unidade?: string,
        public sigla?: string,
        public descricao?: string
    ){}
}

//area
//m
//metro

//area
//cm2
//centrimetro quadrado