# Conversor-de-Medidas

Esta aplicação foi desenvolvida em Angular com o objetivo de se conectar a uma API externa para converter medidas.

Usamos a API do Rodrigo Bianchini, disponível em https://github.com/robianchini/conversor-api.

Baixamos a API e rodamos localmente na porta 3001.

Equipe: Diana Müller, Gabriel Rocha, Guilherme Carvalho, Mariana Silveira e Lina Amaral.
